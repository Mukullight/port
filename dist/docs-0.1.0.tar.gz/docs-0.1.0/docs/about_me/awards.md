## More

### Honors & Awards

<p>
<img src="../../images/about_me/conicyt.png" alt="Smiley face image"
style="float:left; width:65px; height:52px;">
<span style="vertical-align:bottom">
&nbsp <strong>  CONICYT </strong> <br>
&nbsp Santiago, 2017 <br>
</span>
</p>

* National Master's Scholarship
<hr size="30">

<p>
<img src="../../images/about_me/usm.png" alt="Smiley face image"
style="float:left; width:65px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong>  UTFSM </strong> <br>
&nbsp Valparaiso, 2011 - 2016<br><br>
</span>
</p>

* Award: Best student (Class of 2011)
* Award: Best student (Statistic Area)
* Honors: Honor Roll
* Scholarship: Academic Excellence


<hr size="30">




<p>
<img src="../../images/about_me/somachi.png" alt="Smiley face image"
style="float:left; width:70px; height:50px;">
<span style="vertical-align:bottom">
&nbsp <strong> SOMACHI</strong> <br>
&nbsp Santiago, 2010 <br>
</span>
</p>

* Bronze Medal (National Math Olympiad)

<hr size="30">

<p>
<img src="../../images/about_me/sochifi.png" alt="Smiley face image"
style="float:left; width:65px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong> SOCHIFI </strong> <br>
&nbsp Santiago, 2010<br><br>
</span>
</p>

* Participation (National Physics Olympiad)

<hr size="30">

<p>
<img src="../../images/about_me/a1.png" alt="Smiley face image"
style="float:left; width:65px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong> Liceo Octavio Palma Perez</strong> <br>
&nbsp Arica, 2010 <br><br>
</span>
</p>


* Award: Best Scientist


<br>


### Volunteering

<p>
<img src="../../images/about_me/js.png" alt="Smiley face image"
style="float:left; width:91px; height:91px;">
<span style="vertical-align:bottom">
&nbsp <strong> Speaker</strong> <br>
&nbsp Java Script Chile <br>
&nbsp 2024 <br><br>
</span>
</p>

<p>
<img src="../../images/about_me/pythonchile.png" alt="Smiley face image"
style="float:left; width:91px; height:91px;">
<span style="vertical-align:bottom">
&nbsp <strong> Coordination</strong> <br>
&nbsp Python Chile <br>
&nbsp 2022 <br><br>
</span>
</p>

<p>
<img src="../../images/about_me/somachi.png" alt="Smiley face image"
style="float:left; width:91px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong> Partner</strong> <br>
&nbsp SOMACHI <br>
&nbsp 2022
</span>
</p>

# Teaching Experience



<p>
<img src="https://upload.wikimedia.org/wikipedia/commons/4/47/Logo_UTFSM.png" alt="Smiley face image"
style="float:left; width:65px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong> UTFSM</strong> <br>
&nbsp Valparaiso, Chile. <br>
&nbsp 2012 - 2024
</span>
</p>

* **Co-Adviser**. Juan Briceño. Prediction and classification of course of a bank benefit.
* **Lecturer**. Algebra, Calculus and Applied Mathematics ( Introduction
to Machine Learning).
* **Support Teacher**. Design the material related to the exercises, quizzes and tests of the Algebra and Calculus courses.
* **Course Assistant**: Algebra, Calculus, Statistical Inference, Regression
Analysis, Time Series, Statistical Methods, Real Analysis.
<hr size="30">

<p>
<img src="../images/mads.png" alt="Smiley face image"
style="float:left; width:65px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong> MADSc</strong> <br>
&nbsp Valparaiso, Chile. <br>
&nbsp 2023-2024
</span>
</p>

* **Lecturer**. Python Introduction.
* **Coordination**. Supporting in the organization (courses, website, events).

<hr size="30">

<p>
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Escudo_de_la_Pontificia_Universidad_Cat%C3%B3lica_de_Chile.svg/1526px-Escudo_de_la_Pontificia_Universidad_Cat%C3%B3lica_de_Chile.svg.png" alt="Smiley face image"
style="float:left; width:65px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong> DUOC UC</strong> <br>
&nbsp Santiago, Chile. <br>
&nbsp 2022-2023
</span>
</p>

* **Lecturer**. Deep Learning Introduction.
* **Specialist**. Committee tasked with planning, designing, and creating new study programs for Computer Science Department.
<hr size="30">

<p>
<img src="../../images/tripleten.png" alt="Smiley face image"
style="float:left; width:60px; height:60px;">
<span style="vertical-align:bottom">
&nbsp <strong>TripleTen</strong> <br>
&nbsp Bootcamp, Online. <br>
&nbsp 2022-2023 <br>
</span>
</p>

* **Tutor**. Data Science Teacher.
<hr size="30">

<p>
<img src="../../images/cd_03.png" alt="Smiley face image"
style="float:left; width:60px; height:60px;">
<span style="vertical-align:bottom">
&nbsp <strong> Coding Dojo</strong>  <br>
&nbsp Bootcamp, Online. <br>
&nbsp 2022-2023 <br>
</span>
</p>

* **Instructor**. Data Science Teacher.

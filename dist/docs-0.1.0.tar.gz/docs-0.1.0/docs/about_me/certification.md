# Certifications


<p>
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Microsoft_logo.svg/2048px-Microsoft_logo.svg.png" alt="Microsoft logo"
    style="float:left; width:55px; height:55px;">
  <span style="vertical-align:bottom">
    &nbsp;<strong>Microsoft</strong><br>
    &nbsp;Online Certifications
  </span>
</p>

* Microsoft Certified: Azure Fundamentals
* Microsoft Certified: Azure Data Engineer Associate
 Microsoft.


<hr size="30">

<p>
  <img src="https://coursera-university-assets.s3.amazonaws.com/b4/5cb90bb92f420b99bf323a0356f451/Icon.png" alt="Smiley face image"
    style="float:left; width:55px; height:55px;">
  <span style="vertical-align:bottom">
    &nbsp;<strong>DeepLearning.AI </strong><br>
    &nbsp;Online Certifications
  </span>
</p>

* TensorFlow Developer
* Deep Learning
* Machine Learning

<hr size="30">


<p>
  <img src="https://cdn.worldvectorlogo.com/logos/udemy-1.svg" alt="Smiley face image"
    style="float:left; width:55px; height:55px;">
  <span style="vertical-align:bottom">
    &nbsp;<strong>Udemy</strong><br>
    &nbsp;Online Certifications
  </span>
</p>

* Docker Mastery: with Kubernetes + Swarm from a Docker Captain
* Taming Big Data with Apache Spark and Python - Hands On!

<hr size="30">

<p>
  <img src="https://cdn.worldvectorlogo.com/logos/gitlab.svg" alt="Smiley face image"
    style="float:left; width:55px; height:55px;">
  <span style="vertical-align:bottom">
    &nbsp;<strong>Gitlab</strong><br>
    &nbsp;Online Certifications
  </span>
</p>

* Gitlab 101
* Gitlab 201

<hr size="30">

<p>
  <img src="https://149396518.v2.pressablecdn.com/wp-content/uploads/2020/12/cropped-android-chrome-512x512-1.png" alt="Smiley face image"
    style="float:left; width:55px; height:55px;">
  <span style="vertical-align:bottom">
    &nbsp;<strong>Coursera</strong><br>
    &nbsp;Online Certifications
  </span>
</p>

* DevOps on AWS
* Machine Learning
* Preparing for Google Cloud Certification: Machine Learning Engineer
* Microsoft Azure Machine Learning for Data Scientists
* How to Manage a Remote Team
* University Teaching

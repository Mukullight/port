### Students

<p>
<a href="https://github.com/fralfaro/portfolio/blob/main/docs/files/students/memoria_juan.pdf">
    <img src="../../images/hat.png" alt="Smiley face image"
style="float:left; width:90px; height:70px;">
</a>
<span style="vertical-align:bottom">
&nbsp <strong>Prediction and classification of course of a bank benefit.</strong> <br>
&nbsp Juan Briceño, (2022). <br>
</span> <br>
</p>

* Mathematical Engineer, Universidad Técnica Federico Santa María.
* Professor: Dr. Julio Deride. Co-Adviser: Francisco Alfaro.
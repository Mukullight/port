## Languages & Frameworks

<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/800px-Python-logo-notext.svg.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://air-marketing-assets.imgix.net/blog/logo-db/r-logo/r-logo-svg-4.svg" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Jupyter_logo.svg/1200px-Jupyter_logo.svg.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://www.freelogovectors.net/wp-content/uploads/2022/03/azure_databricks_logo_freelogovectors.net_.png" style="float:left; padding-right:10px " width="50" height="50" >
<br>
&nbsp;
&nbsp;

<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/C_Programming_Language.svg/695px-C_Programming_Language.svg.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Tensorflow_logo.svg/1200px-Tensorflow_logo.svg.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://gogeticon.net/files/3163573/d130ef65a8efdfa66fa49eb5ab745cef.png" style="float:left; padding-right:10px " width="55" height="55" >
<img alt="Link" src="https://cdn.worldvectorlogo.com/logos/fastapi-1.svg" style="float:left; padding-right:10px " width="55" height="55" >
<br>
&nbsp;
&nbsp;


<img alt="Link" src="https://cdn.worldvectorlogo.com/logos/scala-4.svg" style="float:left; padding-right:10px " width="38" height="38" >
<img alt="Link" src="https://cdn.worldvectorlogo.com/logos/google-bigquery-logo-1.svg" style="float:left; padding-right:10px " width="55" height="55" >
<img alt="Link" src="https://www.svgrepo.com/show/331488/mongodb.svg" style="float:left; padding-right:10px " width="55" height="55" >
<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Postgresql_elephant.svg/1985px-Postgresql_elephant.svg.png" style="float:left; padding-right:10px " width="53" height="53" >
<br>
&nbsp;
&nbsp;



## Cloud

<img alt="Link" src="https://seeklogo.com/images/G/google-cloud-logo-ADE788217F-seeklogo.com.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Amazon_Web_Services_Logo.svg/1024px-Amazon_Web_Services_Logo.svg.png" style="float:left; padding-right:10px " width="50" height="30" >
<img alt="Link" src="https://github.com/get-icon/geticon/raw/master/icons/azure-icon.svg" style="float:left; padding-right:10px " width="50" height="50" >

&nbsp;
&nbsp;


## Tools and Others


<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ab/Linux_Logo_in_Linux_Libertine_Font.svg/872px-Linux_Logo_in_Linux_Libertine_Font.svg.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://cdn.worldvectorlogo.com/logos/redis.svg" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Git_icon.svg/1200px-Git_icon.svg.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/PyCharm_Icon.svg/2048px-PyCharm_Icon.svg.png" style="float:left; padding-right:10px " width="50" height="50" >
<img alt="Link" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Visual_Studio_2017_Logo.svg/1200px-Visual_Studio_2017_Logo.svg.png" style="float:left; padding-right:10px " width="50" height="50" >

<br>
&nbsp;
&nbsp;
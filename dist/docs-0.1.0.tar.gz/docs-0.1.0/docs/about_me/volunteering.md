# Volunteering

<p>
<img src="../images/js.png" alt="Smiley face image"
style="float:left; width:91px; height:91px;">
<span style="vertical-align:bottom">
&nbsp <strong> Speaker</strong> <br>
&nbsp Java Script Chile <br>
&nbsp 2024 <br><br>
</span>
</p>

<p>
<img src="../images/pythonchile.png" alt="Smiley face image"
style="float:left; width:91px; height:91px;">
<span style="vertical-align:bottom">
&nbsp <strong> Coordination</strong> <br>
&nbsp Python Chile <br>
&nbsp 2022 <br><br>
</span>
</p>

<p>
<img src="../../images/somachi_svg.svg" alt="Smiley face image"
style="float:left; width:91px; height:65px;">
<span style="vertical-align:bottom">
&nbsp <strong> Partner</strong> <br>
&nbsp SOMACHI <br>
&nbsp 2022
</span>
</p>